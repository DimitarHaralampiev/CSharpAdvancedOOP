﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortages
{
    public interface IBirthday
    {
        public string Birthday { get; }
    }
}
