﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FoodShortages
{
    public interface IIdentifiable
    {
        public string Id { get; }
    }
}
